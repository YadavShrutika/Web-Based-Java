import React, { useState } from "react";
import "../styles/AdminPage.css"; 
import { NavBar } from "./NavBar";

const AdminPage = () => {
  const [activeTab, setActiveTab] = useState("dashboard");

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <>
      <NavBar />
      <div className="admin-container">
        <div className="sidebar">
          <h2 className="sidebar-title">Admin Dashboard</h2>
          <ul className="sidebar-menu">
            <li
              className={activeTab === "dashboard" ? "active" : ""}
              onClick={() => handleTabClick("dashboard")}
            >
              Dashboard
            </li>
            <li
              className={activeTab === "users" ? "active" : ""}
              onClick={() => handleTabClick("users")}
            >
              User Management
            </li>
            <li
              className={activeTab === "jobs" ? "active" : ""}
              onClick={() => handleTabClick("jobs")}
            >
              Job Management
            </li>
            <li
              className={activeTab === "applications" ? "active" : ""}
              onClick={() => handleTabClick("applications")}
            >
              Application Management
            </li>
          </ul>
        </div>

        <div className="main-content">
          {activeTab === "dashboard" && (
            <div className="dashboard">
              <h3>Dashboard Overview</h3>
              <p>Active Users: 500</p>
              <p>Job Listings: 150</p>
              <p>Applications: 300</p>
            </div>
          )}

          {activeTab === "users" && (
            <div className="user-management">
              <h3>User Management</h3>
              <p>List of users (Job Seekers/Recruiters) will appear here.</p>
            </div>
          )}

          {activeTab === "jobs" && (
            <div className="job-management">
              <h3>Job Management</h3>
              <p>List of job postings will appear here.</p>
            </div>
          )}

          {activeTab === "applications" && (
            <div className="application-management">
              <h3>Application Management</h3>
              <p>List of applications will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default AdminPage;
