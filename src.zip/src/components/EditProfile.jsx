import axios from "axios";
import { useEffect, useState } from "react";
import '../styles/EditProfile.css'; 
import NaviBar from "./NaviBar";

const EditProfile = () => {
  const [user, setUser] = useState({
    name: "",
    email: "",
    phone: "",
  });

  useEffect(() => {
    
    const fetchUserProfile = async () => {
      try {
        const response = await axios.get("http://localhost:5000/api/user/profile"); 
        setUser(response.data); 
      } catch (error) {
        console.error("Error fetching user profile", error);
      }
    };
    fetchUserProfile();
  }, []); 

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.put("http://localhost:5000/api/user/profile", user); // Replace with the actual API
      console.log("Profile updated successfully", response.data);
    } catch (error) {
      console.error("Error updating profile", error);
    }
  };

  return (
    <>
    <NaviBar/>
    <div className="edit-profile-container">
      <h1>Edit Your Profile</h1>
      <p>Update your personal details to keep your profile current.</p>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Full Name</label>
          <input
            type="text"
            id="name"
            name="name"
            className="form-control"
            placeholder="Enter your full name"
            value={user.name}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email Address</label>
          <input
            type="email"
            id="email"
            name="email"
            className="form-control"
            placeholder="Enter your email address"
            value={user.email}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label htmlFor="phone">Phone Number</label>
          <input
            type="text"
            id="phone"
            name="phone"
            className="form-control"
            placeholder="Enter your phone number"
            value={user.phone}
            onChange={handleChange}
          />
        </div>
        <div className="button-group">
          <button type="button" className="btn edit-btn">
            Edit
          </button>
          <button type="submit" className="btn save-btn">
            Save Changes
          </button>
        </div>
      </form>
    </div>
    </>
  );
};

export default EditProfile;
