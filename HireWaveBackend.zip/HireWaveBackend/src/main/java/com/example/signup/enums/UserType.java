package com.example.signup.enums;

public enum UserType {
    JOB_SEEKER,
    ADMIN,
    RECRUITER
}
